
Customizing
===========

Session classes
---------------

Session classes are ready for customizing.

.. autoclass:: vk.Session
